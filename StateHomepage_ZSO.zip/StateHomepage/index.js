var bg1 = document.getElementById("backgroundImage1");
var bg2 = document.getElementById("backgroundImage2");

var stateSeal = document.getElementById("stateSeal");
var sealBanner = document.getElementById("sealBanner");

var closeSealBanner = document.getElementById("closeSealBanner");

var GMT = document.getElementById("GMT");
var Vermonter = document.getElementById("Vermonter");

var clickMeNotification = document.getElementById("clickMe");

one();
function one() {
	window.setTimeout(function() {
		bg1.style.opacity = 0;
		two();
	}, 4000);
}
function two() {
	window.setTimeout(function() {
		bg1.style.opacity = 1;
		bg1.style["box-shadow"] = null;
		one();
	}, 4000);
}
window.setTimeout(function() {
	clickMeNotification.style.opacity = 1;
	window.setTimeout(function() {
		clickMeNotification.style.opacity = 0;
	}, 5000);
}, 10000);
stateSeal.addEventListener("click", function() {
	stateSeal.style.transform = "translateX(-60%)";
	sealBanner.style.opacity = 1;
	clickMeNotification.style.opacity = 0;
	window.setTimeout(function() {
		closeSealBanner.style.opacity = 1;
		GMT.style.opacity = 1;
		Vermonter.style.opacity = 1;
	}, 1000);
});
closeSealBanner.addEventListener("click", function() {
	stateSeal.style.transform = "translateX(0%)";
	sealBanner.style.opacity = 0;
	closeSealBanner.style.opacity = 0;
	GMT.style.opacity = 0;
	Vermonter.style.opacity = 0;
});
